#include <stdio.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

void str_echo(int connfd, struct sockaddr * cliaddress, int clilen){

    int bufsize = 1024;
    char * buffer = malloc(bufsize);
    int n;
    int addrlen;
    while( 1 ){
        addrlen = clilen;
        n = recvfrom (connfd, buffer, bufsize, 0, cliaddress, &addrlen);
        sendto(connfd, buffer, bufsize, 0,cliaddress, addrlen);
    }
}

int main()
{
    struct sockaddr_in address;
    int listenfd;
    listenfd = socket(AF_INET, SOCK_DGRAM , 0);
    if(listenfd < 0){
        perror("socket");
    }
    else{
        printf("\nSocket Created\n");
    }
    address.sin_family = AF_INET;
    address.sin_port = htons(14000);
    address.sin_addr.s_addr = INADDR_ANY;

    int x;
    if( (x = bind(listenfd, (struct sockaddr *)&address, sizeof(address))) == 0){
        printf("\nBinding the socket\n");
    }
    else{
        perror("bind");
    }
    struct sockaddr_in cliaddress;
    str_echo(listenfd,(struct sockaddr *)&cliaddress,sizeof(cliaddress));
    close(listenfd);
    
}