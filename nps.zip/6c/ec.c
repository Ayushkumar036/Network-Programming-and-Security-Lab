#include <stdio.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

void str_echo(int connfd, FILE * fp,struct sockaddr * servaddress, int servilen){

    int bufsize = 1024;
    char * buffer = malloc(bufsize);
    int n;
    while( fgets(buffer, bufsize, fp)!=NULL ){
        sendto(connfd, buffer, bufsize, 0, servaddress, servilen);
        if((n = recvfrom(connfd, buffer, bufsize, 0, NULL, NULL) )> 0)    // recvfrom anyone hence NULL
            fputs(buffer, stdout);
    }
    printf("\nEOF");
}
int main(int argc , char * argv[])
{
    struct sockaddr_in address;
    int listenfd;
    listenfd = socket(AF_INET, SOCK_DGRAM , 0);
    if(listenfd < 0){
        perror("socket");
    }
    else{
        printf("\nSocket Created\n");
    }
    address.sin_family = AF_INET;
    address.sin_port = htons(14000);
    inet_pton(AF_INET, argv[1], &address.sin_addr);
    str_echo(listenfd, stdin, (struct sockaddr *)&address, sizeof(address));
    return close(listenfd);
}
