#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>


void str_echo(int connfd,FILE *fp)
{
int buffersize=1024;
char *buffer=malloc(buffersize);
int n;
again:
while( fgets(buffer,buffersize,fp)!=NULL)
{
send(connfd,buffer,buffersize,0);
if( (n=recv(connfd,buffer,buffersize,0))>0)
fputs(buffer,stdout);

if(n<0)
goto again;
}
}


int main(int argc,char *argv[])
{
int listenfd;
struct sockaddr_in address;

listenfd=socket(AF_INET,SOCK_STREAM,0);
if(listenfd<0)
perror("socket");
else
printf("socket created\n");

address.sin_port=htons(15001);
address.sin_family=AF_INET;
inet_pton(AF_INET,argv[1],&address.sin_addr);  // 

if( connect(listenfd,(struct sockaddr*)&address,sizeof(address))==0)
printf("connected to the server\n");
else
perror("connect");

str_echo(listenfd,stdin);

return close(listenfd);
}
