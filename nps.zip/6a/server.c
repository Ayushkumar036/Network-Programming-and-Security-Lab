#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<netinet/in.h>

void str_echo(int connfd,int port)
{
int buffersize=1024;
char *buffer = malloc(buffersize);
int n;
again:
while( (n=recv(connfd,buffer,buffersize,0))>0)
{
send(connfd,buffer,buffersize,0);
if(n<0)
goto again;
}
}


int main()
{
int listenfd;
struct sockaddr_in address;

listenfd=socket(AF_INET,SOCK_STREAM,0);
if(listenfd<0)
perror("socket");
else
printf("socket created\n");

address.sin_family=AF_INET;
address.sin_port=htons(15001);
address.sin_addr.s_addr=INADDR_ANY;


if( bind(listenfd,(struct sockaddr*)&address,sizeof(address) ) == 0)
printf("binding....\n");
else
perror("bind");

listen(listenfd,3);

while(1)
{
int connfd;
struct sockaddr_in cliaddress;
int addrlen=sizeof(struct sockaddr_in);

connfd=accept(listenfd,(struct sockaddr *)&address,&addrlen);
printf("Ip %s connected to PORT %d\n",inet_ntoa(cliaddress.sin_addr),ntohs(cliaddress.sin_port));

int pid;
pid=fork();
if(pid==0)
{
close(listenfd);
str_echo(connfd,ntohs(cliaddress.sin_port));
exit(1);
}

close(connfd);
}

return close(listenfd);

}
