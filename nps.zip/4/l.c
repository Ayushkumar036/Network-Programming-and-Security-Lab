#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <time.h>
#include <string.h>
#define HELLO_GROUP "225.0.0.37"
#define HELLO_PORT 12345

int main()
{
    struct sockaddr_in address;
    struct ip_mreq mreq;
    int fd;
    int yes = 1;

    if( (fd = socket(AF_INET, SOCK_DGRAM, 0)) <0){
        perror("socket");
        exit(0);
    }

    if(setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes) ) < 0){
        perror("setsockopt");
        exit(0);
    }
    //memset(&address, sizeof(address), 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(HELLO_PORT);

    if(bind(fd, (struct sockaddr *)&address, sizeof(address)) <0){
        perror("bind");
        exit(0);
    }

    mreq.imr_multiaddr.s_addr = inet_addr(HELLO_GROUP);
    mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    if(setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq) ) < 0){
        perror("setsockopt");
        exit(0);
    }

    while(1){
        int bufsize = 1024;
        char * buffer = malloc(bufsize);
        //struct sockaddr m;
        int addrlen = sizeof(address);
        if(recvfrom(fd, buffer, bufsize, 0 ,(struct sockaddr *)&address, &addrlen)> 0){
            fputs(buffer, stdout);
        }
    }


    
}
