#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <string.h>

#define HELLO_GROUP "225.0.0.37"
#define HELLO_PORT 12345

int main()
{
    struct sockaddr_in address;
    //struct ip_mreq mreq;
    int fd;
    char message[] = "RVCE-CSE\n";
    if( (fd = socket(AF_INET, SOCK_DGRAM, 0)) <0){
        perror("socket");
        exit(0);
    }
    //memset(&address, sizeof(address), 0);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = inet_addr(HELLO_GROUP);
    address.sin_port = htons(HELLO_PORT);

    while(1){
        int bufsize = sizeof(message);
        struct sockaddr m;
        int addrlen = sizeof(m);
        if(sendto(fd, message, bufsize, 0 , (struct sockaddr *) &address, addrlen)> 0){
            
        }
        sleep(1);
    }


    
}
