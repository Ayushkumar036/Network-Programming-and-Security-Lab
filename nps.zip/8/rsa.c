#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long int gcd( long int a, long int b)
{
    if( a== 0 ){
        return b;
    }
    if( b == 0){
        return a;
    }
    else
    {
        return gcd(b, a%b);
    }
}

long int isprime(long int a )
{
    long int i;
    for( i=2; i < a; i++){
        if (a%i == 0 )
        return 0;
    }
    return 1;
}

long int encrypt( char ch, long int n , long int e)
{
    long int temp = ch;
    long int i ;
    for( i = 1 ; i < e; i++ ){
        temp = (temp * ch)%n;
    }
    return temp; 
}

char decrypt( long int ok, long int n , long int d)
{
    long int temp = ok;
    long int i ;
    for( i = 1 ; i < d; i++ ){
        ok = (temp * ok)%n;
    }
    return ok; 
}

int main(){

    char s[100];
    printf("\nEnter the string to be encrpyted :");
    scanf("%s",s);
    //gets(s);
    int l = strlen(s);
    long int p, q;
    do{
        p = rand() % 800;
    }while( !isprime(p));
        
    do{
        q = rand() % 800;
    }while( !isprime(q));
    
    
    long int n = p *q;   // public key
    printf("\nThe two numbers p , q are %ld %ld and the product n is %ld\n", p, q, n);
    
    long int phi = (p-1)*(q-1);
    printf("\nThe number phi is : %ld\n",phi);
    long int e, d;
    do{
        e = rand() % phi;
    }while(gcd(phi, e)!=1);
    
    do{
        d = rand() % phi;
    }while( ((d*e)%phi) != 1);
    
    long int en[100];
    int i;
    for(i = 0 ; i < l ; i++ )
    {
        en[i] = encrypt(s[i], n, e);
    }
    printf("\nThe encrypted message being the following : " );
    for(i = 0 ; i < l ; i++ )
    {
        printf("%ld",en[i]);
    }
    printf("\n");
    char de[100];
    for(i = 0 ; i < l ; i++ )
    {
        de[i] = decrypt(en[i], n , d);
    } 
    printf("\nThe decrypted message being the following : " );
    for(i = 0 ; i < l ; i++ )
    {
        printf("%c",de[i]);
    }
    printf("\n");
}
