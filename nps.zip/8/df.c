#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int compute( int a, int m , int n){

   int i,temp=1;
   for(i=1;i<=m;i++)
   temp=(temp*a)%n;
   
   return temp;
}

int main()
{
    int p = 23, g = 5;
    int a , b, A, B;
    a = 1 + rand()%1000;
    b = 1 + rand()%1000;
    A = compute(g,a,p);
    B = compute(g,b,p);
    int x = compute(B,a,p);
    int y = compute(A,b,p);
    printf("x is %d and y is %d\n", x,y);
    return 0;
}
