#include <stdio.h>
#include <stdlib.h>

int main(){

    int data[7], datarec[7];
    int i;
    printf("\nEnter the data values i.e the data bits 0 , 1, 2, 4:\n");
    scanf("%d%d%d%d",&data[0],&data[1],&data[2],&data[4]);

    data[6] = data[0]^data[2]^data[4];
    data[5] = data[0]^data[1]^data[4];
    data[3] = data[0]^data[1]^data[2]; 


    printf("\nEncoded data is :");
        for( i = 0 ; i < 7 ; i++){
        printf("%d",data[i]);
    }
    printf("\n");

    printf("\nEnter the recieved data : \n");
    for( i = 0 ; i < 7 ; i++){
        scanf("%d",&datarec[i]);
    }
    
    int c,c1,c2,c3;

    c1 = datarec[6]^datarec[0]^datarec[2]^datarec[4];
    c2 = datarec[5]^datarec[0]^datarec[1]^datarec[4];
    c3 = datarec[3]^datarec[0]^datarec[2]^datarec[1];

    c = c3*4 +2*c2 + c1;

    if( c==0){
        printf("\nError NOT detected !!\n");
        exit(0);
    }
    else{
        printf("\nError bit is %d ",c);
        printf("\nActual datarec should have been : ");

        if(datarec[7-c] == 0){
            datarec[7-c] = 1;
        }
        else{
            datarec[7-c] = 0;
        }


        for( i = 0; i< 7; i++){
            printf("%d",datarec[i]);
        }
        printf("\n");

    }

}