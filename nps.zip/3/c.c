#include <stdio.h>
#include <stdlib.h>
int checking_sum(){
    int num[10];
    int i, sum = 0;
    printf("\nEnter the value of this iteration :\n");
    for( i = 0 ; i< 9 ; i++){
        scanf("%d", &num[i]);
        sum += (unsigned int)(num[i]);

        while( sum >> 16){
            sum = (sum&0xFFFF) + (sum>>16);
        }
    }
    sum = ~sum;
    return sum;
}

int main(){
    printf("\nEnter the first number :\n");
    int x = checking_sum();
    printf("\nEnter the second number :\n");
    int y = checking_sum();
    if ( x == y){
        printf("\nBoth the checksums are same\n");
        printf("\nFirst checksum is : %d\n",x);
        printf("\nSecond checksum is : %d\n",y);
        exit(0);
    }
    else{
        printf("\nBoth the checksums are NOT same\n");
        printf("\nFirst checksum is : %d\n",x);
        printf("\nSecond checksum is : %d\n",y);
        exit(0);
    }
}