#include <stdio.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

void str_echo(int connfd, int port){

    int bufsize = 1024;
    char * buffer = malloc(bufsize);
    int n;
    again:
    while( (n = recv(connfd, buffer, bufsize, 0) )> 0 ){
        //send(connfd, buffer, bufsize, 0);
        printf("The client at port %d requested for command :%s", port, buffer);
        system(buffer);
    }
    if(n < 0)
    goto again;
}

int main()
{
    struct sockaddr_in address;
    int listenfd;
    listenfd = socket(AF_INET, SOCK_STREAM , 0);
    if(listenfd < 0){
        perror("socket");
    }
    else{
        printf("\nSocket Created\n");
    }
    address.sin_family = AF_INET;
    address.sin_port = htons(14000);
    address.sin_addr.s_addr = INADDR_ANY;

    int x;
    if( (x = bind(listenfd, (struct sockaddr *)&address, sizeof(address))) == 0){
        printf("\nBinding the socket\n");
    }
    else{
        perror("bind");
    }

    listen(listenfd, 3);
    while(1){
        struct sockaddr_in cliaddress;
        int addrlen = sizeof(struct sockaddr_in);
        int connfd = accept(listenfd, (struct sockaddr *)&address, &addrlen);
        
        // different
        
        //int i = getpeername(connfd, (struct sockaddr *)&cliaddress,&cliaddress.sin_addr.s_addr); // new_socket,  , 
        int pid;
        printf("\nWe connected with %s IP and %d port\n", inet_ntoa(cliaddress.sin_addr), ntohs(cliaddress.sin_port));
        pid = fork();
        if(pid == 0)
        {
            close(listenfd);
            str_echo(connfd,ntohs(cliaddress.sin_port));
            exit(0);
        }
        
        close(connfd);
    }
}
