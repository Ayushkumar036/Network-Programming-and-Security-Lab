#include <stdio.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

void str_echo(int connfd, FILE * fp){

    int bufsize = 1024;
    char * buffer = malloc(bufsize);
    int n;
    while( fgets(buffer, bufsize, fp)!=NULL ){
        send(connfd, buffer, bufsize, 0);
        if((n = recv(connfd, buffer, bufsize, 0) )> 0);
            // fputs(buffer, stdout);
    }
    printf("\nEOF");
}

int main(int argc , char * argv[])
{
    struct sockaddr_in address;
    int listenfd;
    listenfd = socket(AF_INET, SOCK_STREAM , 0);
    if(listenfd < 0){
        perror("socket");
    }
    else{
        printf("\nSocket Created\n");
    }
    address.sin_family = AF_INET;
    address.sin_port = htons(14000);
    inet_pton(AF_INET, argv[1], &address.sin_addr);

    int x;
    if( (x = connect(listenfd, (struct sockaddr *)&address, sizeof(address))) == 0){
        printf("\nconnecting the socket\n");
    }
    else{
        perror("connect");
    }

    str_echo(listenfd, stdin);
    return close(listenfd);
}